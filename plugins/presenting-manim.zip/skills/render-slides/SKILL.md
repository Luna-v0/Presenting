---
name: render-slides
description: Use when a deck needs a .pptx — a brief with `target: slides`, "make the slides", "I need a PowerPoint", "put it on Drive". Write a plain Python script for that deck using python-pptx. There is no shared renderer and no template; do not build one. Read "What broke" before writing anything.
---

# Render (slides)

Read the screenplay, write a Python script for that deck, run it, check it.

```bash
cd manim-videos
uv run python decks/<slug>/out/build_pptx.py
```

## Slides are not the manim deck

They are different media and they should look different. Do **not** import the
manim layout geometry, do not convert manim units to inches, and do not try to
reproduce a beat's manim composition slide-for-slide. Work in PowerPoint's own
terms — inches, points, text boxes — and lay each slide out the way a good slide
would be laid out.

What carries across is the **identity and the content**: the palette, the type
hierarchy, the claim, the figure, the speaker notes. Not the rectangles.

## What broke, and the rules that follow

An earlier version generated a template with one named slide layout per catalog
entry, cloning `slideLayout` parts at the XML level because python-pptx has no
API for adding a layout. It round-tripped cleanly through python-pptx and
**would not open in PowerPoint**.

1. **Never do XML surgery.** No cloned layouts, no hand-built `<p:sldLayout>`,
   no editing the theme part. Use the stock template's **Blank** layout and add
   shapes to it. python-pptx's documented API is enough for everything here.
2. **No abstraction.** A pptx is generated once and then edited by hand in
   PowerPoint; regenerating throws those edits away. A readable script the user
   can open and change beats a renderer they would have to learn. When a deck
   needs something unusual, edit that deck's script.

## The identity

Read `manim-videos/identity/tokens.yaml` for the live values rather than
trusting this list, but it is:

| | |
|---|---|
| ground (slide background) | `#E4DCC6` |
| ink (all body text) | `#232A24` |
| muted (captions, footer) | `#5F5A4B` |
| structure fill / stroke | `#CFC6AE` / `#8C8470` |
| green tint / mid / dark | `#CCE0C6` / `#3D6349` / `#1E3527` |
| yellow tint / mid / dark | `#F6E5A5` / `#A87F20` / `#55400E` |

**Pairing is not optional.** An accent fill carries its own `dark` text; ground
and structure carry `ink`. There is no light text on a dark fill anywhere.

**Accents are positional, not valenced.** Green is the first of two things being
related, yellow the second. Green alone when a beat marks one thing; never
yellow alone. Never a third colour.

**Type**, in points on a 13.333 x 7.5 in slide — pick what looks right, these
are the intended hierarchy:

| step | pt | use |
|---|---|---|
| display | 68 | title slide, section breaks |
| title | 52 | slide titles |
| claim | 40 | the one-line claim |
| body | 28 | list items, definitions |
| caption | 22 | attributions, footer |

**Fonts must be portable.** A pptx names one font and the opening machine either
has it or silently substitutes — and these decks get presented from borrowed
laptops. Use **Times New Roman** and **Courier New**: metric-compatible with the
Liberation faces the manim target uses, and present on every Windows and Mac.

## Composing the slides

Chrome: a centred bold title with a thin green rule beneath it, sized to the
title rather than a fixed width; section name lower left and slide number lower
right, both muted and small. Section breaks and single-statement slides get no
chrome at all.

Per beat, use the `layout` name as a description of intent, not a spec:

- **title-card** — title, subtitle, author, affiliation, date. No chrome.
- **section-break** — the section name, large and centred, nothing else.
- **claim-only / callout** — one sentence, centred, room around it.
- **claim-above-figure** — claim across the top, picture under it. The workhorse.
- **build-list** — **expands into sibling slides**, one per item revealed.
  Near-identical consecutive slides are correct here; the user's beamer decks
  already do this.
- **two-up-compare** — two labelled halves.
- **equation-annotated** — the formula, with up to two annotation boxes beneath
  in the accent tints.
- **table-accented** — a table with one row or column in the green tint.
- **figure-with-callouts** — figure with up to three boxes beside it.
- **activity-setup / activity-parking** — the task, then the instructions that
  stay on screen while people work.
- **backup** — whatever it wraps, with "Backup" in the footer.
- **raw** — **skip it.** It is a manim escape hatch. If the slides deck needs
  what it shows, render a still into `assets/built/<beat-id>.png` and give the
  beat a normal layout.

Let text breathe. Centre a short block in its space rather than pinning it to
the top; empty space under a two-line list reads as unfinished.

## Content rules from the format

- **Budgets**: `identity/budgets.json` under the `"pptx"` key, not `"manim"`.
  Over budget means it will not fit.
- **Speaker notes are directives**, built from `Claim` and `Note` — things to
  *do*: position, emphasise, contrast, frame. Never sentences to read aloud.
  **`Cue` never ships in speaker notes**; it is the user's private shorthand.
- **`Note` and `Cue` are verbatim** wherever they appear. Never reworded.
- **Constructible visuals need stills.** Run `shot-list` against the slides
  target first — it lists which diagrams to render out of manim into
  `assets/built/`. Without them those slots come out empty.
- **Attribution** goes under the figure in caption style wherever
  `visual.attribution` is set.

## Regeneration destroys hand edits

Generation is one-shot. Re-running the script produces a **new file**; anything
edited in PowerPoint or Google Slides is lost. Say this before they start
editing, not after. If they want to keep editing in Slides, that is the end of
the pipeline for that deck — say so plainly rather than implying a round trip.

## Check it. python-pptx reading its own output is not a check.

That circularity is exactly what shipped a file PowerPoint would not open.

1. Reopen with python-pptx: slide count, and the text you expect where you
   expect it.
2. **Render it through LibreOffice** — installed here, and a genuinely
   independent implementation. If it cannot open the file, PowerPoint almost
   certainly cannot either.

   ```bash
   soffice --headless --convert-to pdf --outdir /tmp decks/<slug>/out/<slug>.pptx
   pdftoppm -png -r 60 -f 1 -l 12 /tmp/<slug>.pdf /tmp/page
   uv run python scripts/contact_sheet.py --frames /tmp --out /tmp/sheets
   ```

   Then **look at the pages.** Overflow, overlap, missing content and bad
   spacing all show up here, and nothing else will tell you.
3. **Ask the user to open it once** in PowerPoint or Google Slides, and say why.
   LibreOffice agreeing is strong evidence, not the same renderer.

## Drive

**By hand — the user uploads it themselves.** Settled; do not offer to automate
it and do not ask again. Print the absolute path and stop. Never upload a deck
anywhere: it is outward-facing, and a talk in progress is not yours to publish.
